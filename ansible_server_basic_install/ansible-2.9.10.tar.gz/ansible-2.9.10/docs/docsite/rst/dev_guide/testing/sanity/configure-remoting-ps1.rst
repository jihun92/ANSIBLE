configure-remoting-ps1
======================

The file ``examples/scripts/ConfigureRemotingForAnsible.ps1`` is required and must be a regular file.
It is used by external automated processes and cannot be moved, renamed or replaced with a symbolic link.
