use-compat-six
==============

Use ``six`` from ``module_utils`` instead of ``six``.
