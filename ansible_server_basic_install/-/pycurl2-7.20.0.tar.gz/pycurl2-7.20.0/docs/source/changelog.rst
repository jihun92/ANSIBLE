.. module:: PycURL2

.. include:: ../../ChangeLog

