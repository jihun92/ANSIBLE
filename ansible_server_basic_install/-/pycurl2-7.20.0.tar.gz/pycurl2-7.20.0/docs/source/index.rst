.. PycURL2 documentation master file, created by
   sphinx-quickstart on Sat Sep 29 21:06:32 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../../README.rst

PycURL2 documentation
---------------------

.. toctree::
   :maxdepth: 2

   install
   intro
   api
   callbacks


Additional Information
----------------------

.. toctree::
   :maxdepth: 2

   changelog
   TODO

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

