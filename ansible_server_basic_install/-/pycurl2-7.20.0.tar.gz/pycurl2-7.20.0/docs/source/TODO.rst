.. module:: PycURL2


TODO
----

- More documentation
