Sanity Tests » changelog
========================

Basic linting of changelog fragments with yamllint and rstcheck.

One or more of the following sections are required:

- major_changes
- minor_changes
- deprecated_features
- removed_features
- bugfixes
- known_issues

New modules and plugins must not be included in changelog fragments.
